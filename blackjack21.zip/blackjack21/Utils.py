from itertools import product

class Utils():
    VALORES_POSIBLES_ACES = {1, 11}

    @staticmethod
    def es_un_numero(numero):
        numero_valido = True

        try:
            int(numero)
        except ValueError:
            numero_valido = False

        return numero_valido

    @staticmethod
    def obtener_valor_numerico_carta(carta):
        if Utils.es_un_numero(carta.valor_carta):
            return int(carta.valor_carta)
        else:
            return 10

    @staticmethod
    def obtener_puntaje_mano(mano):
        sumatoria = 0
        numero_de_aces_encontrados = 0
        letra_carta = ""

        for carta in mano:
            if Utils.es_un_numero(carta.valor_carta):
                sumatoria += int(carta.valor_carta)
            else:
                letra_carta = carta.valor_carta.upper().strip()

                if letra_carta == 'Q' or letra_carta == 'J' \
                        or letra_carta == 'K':
                    sumatoria += 10
                elif 'A' == carta.valor_carta.upper().strip():
                    # se agrega al contador de aces
                    numero_de_aces_encontrados += 1

        return Utils.obtener_el_mejor_puntaje(sumatoria, numero_de_aces_encontrados)

    @staticmethod
    def sum_lista_int(lista_int):
        sum = 0

        for num in lista_int:
            sum += num

        return sum

    @staticmethod
    def obtener_el_mejor_puntaje(puntaje_total, numero_de_aces_obtenidos):

        permutaciones_aces = list(product(Utils.VALORES_POSIBLES_ACES, repeat=numero_de_aces_obtenidos))
        puntajes_totales = []
        puntajes_menores_al_black_jack = []
        puntajes_mayores_al_black_jack = []

        for s in permutaciones_aces:
            puntajes_totales.append(puntaje_total + Utils.sum_lista_int(s))

        #verifica si hay un black jack 21 (un valor igual a 21)
        for s in puntajes_totales:
            if s == 21:
                return 21

        #obtiene todos los numeros menores a 21 y los almacena de esa lista
        for s in puntajes_totales:
            if s < 21:
                puntajes_menores_al_black_jack.append(s)

        if len(puntajes_menores_al_black_jack) > 0:
            return min(puntajes_menores_al_black_jack)

        #obtiene todos los puntajes mayores a 21
        for s in puntajes_totales:
            if s > 21:
                puntajes_mayores_al_black_jack.append(s)

        if len(puntajes_mayores_al_black_jack) > 0:
            return min(puntajes_mayores_al_black_jack)

        return puntaje_total

    @staticmethod
    def verificar_ganador(jugador, crupier):
        puntaje_jugador = Utils.obtener_puntaje_mano(jugador.cartas_jugador)
        puntaje_crupier = Utils.obtener_puntaje_mano(crupier.cartas_crupier)

        if puntaje_crupier > 21 and puntaje_jugador > 21:
            print("Ninguno de los dos jugadores gana")
        elif puntaje_crupier == 21 and puntaje_jugador == 21:
            print("Se llega a un empate")
        elif puntaje_crupier == puntaje_jugador:
            print("Se llega a un empate")
        elif puntaje_jugador > 21 and puntaje_crupier <= 21:
            print("El crupier gana")
            crupier.reclamar_dinero_jugador(jugador, jugador.dinero_por_apostar)
        elif puntaje_jugador < puntaje_crupier and puntaje_crupier <= 21:
            print("El crupier gana")
            crupier.reclamar_dinero_jugador(jugador, jugador.dinero_por_apostar)
        elif puntaje_crupier > 21 and puntaje_jugador <= 21:
            print("Ganas la partida")
            jugador.reclamar_dinero_apostado()
        elif puntaje_crupier < puntaje_jugador and puntaje_jugador <= 21:
            print("Ganas la partida")
            jugador.reclamar_dinero_apostado()

    @staticmethod
    def reiniciar_juego(jugador, crupier, mazo):
        mazo.inicializar_baraja()
        















