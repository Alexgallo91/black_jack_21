from random import randint
from Utils import Utils

class Crupier():

    def __init__(self):
        self.cartas_crupier = []
        self.monto_crupier = 100

    def agarrar_carta_mazo(self, mazo):
        self.cartas_crupier.append(mazo.agarrar_carta())

        if len(self.cartas_crupier) == 1:
            self.cartas_crupier[0].establecer_carta_arriba(True)

    def establecer_cartas_boca_arriba(self):
        for carta in self.cartas_crupier:
            carta.establecer_carta_arriba(True)

    def reclamar_dinero_jugador(self, jugador, monto_a_reclamar):
        self.monto_crupier += monto_a_reclamar
        jugador.reducir_monto_jugador(monto_a_reclamar)
        jugador.dinero_por_apostar = 0


    def mostrar_cartas_crupier(self):
        cadena = ""

        for i, carta in enumerate(self.cartas_crupier, 1):
            if not carta.boca_arriba:
                cadena += "[{}° carta] ".format(i)
            else:
                cadena += "[{}] ".format(carta)

        return cadena

    #el crupier podra pedir una carta solo si la suma de su mano inicial sea menor a 17, en caso contrario se planta
    def establecer_jugada(self, mazo):
        while Utils.obtener_puntaje_mano(self.cartas_crupier) < 17:
            self.agarrar_carta_mazo(mazo)

        self.establecer_cartas_boca_arriba()




