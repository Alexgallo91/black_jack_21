from os import system, name
from Utils import *

class Pantalla():

    @staticmethod
    def imprimir_pantalla(jugador, crupier):
        pass

    @staticmethod
    def imprimir_opciones_jugador():
        cadena = ""
        cadena += "Que jugada quieres realizar?:\n"
        cadena += "1 - Pedir carta\n"
        cadena += "2 - Pasar"
        print(cadena)

    @staticmethod
    def limpiar_pantalla():
        if name == 'nt':
            _ = system('cls')
        else:
            _ = system('clear')

    @staticmethod
    def mensaje_bienvenida():
        cadena = ""
        cadena += "|||||||||||||||||||||||||||||||||||||||||||||||||||\n"
        cadena += "||                                               ||\n"
        cadena += "||         BIENVENIDO AL BLACK JACK 21           ||\n"
        cadena += "||                                               ||\n"
        cadena += "|||||||||||||||||||||||||||||||||||||||||||||||||||\n"
        print(cadena)


    @staticmethod
    def imprimir_pantalla_estado_jugadores(crupier, jugador):
        cadena = "--Crupier--"
        cadena += "\n"
        cadena += "Dinero Crupier: {}".format(crupier.monto_crupier)
        cadena += "\ncartas crupier: {}".format(crupier.mostrar_cartas_crupier())
        cadena += "\nPuntaje del Crupier: {}".format(Utils.obtener_puntaje_mano(crupier.cartas_crupier))
        cadena += "\n"
        cadena += "\n--Jugador--"
        cadena += "\nDinero Jugador: {}".format(jugador.monto_jugador)
        cadena += "\ncartas jugador: {}".format(jugador.mostrar_cartas_jugador())
        cadena += "\nPuntaje del jugador: {}".format(Utils.obtener_puntaje_mano(jugador.cartas_jugador))
        print("{}".format(cadena))



