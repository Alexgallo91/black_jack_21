from Carta import Carta
from random import shuffle, randint

SIMBOLOS = ["corazones", "diamantes", "treboles", "espadas"]
VALORES_CARTAS = [2,3,4,5,6,7,8,9,10,'J','K','Q','A']

class Mazo():

    def __init__(self, baraja=[]):
        self.baraja = baraja
        self.inicializar_baraja()

    def inicializar_baraja(self):
        for simbolo in SIMBOLOS:
            for valor in VALORES_CARTAS:
                self.baraja.append(Carta(valor, simbolo))

        shuffle(self.baraja)

    def __repr__(self):
        baraja = ""

        for carta in self.baraja:
            baraja += "{}\n".format(carta)

        return baraja

    def __len__(self):
        return len(self.baraja)

    def agarrar_carta(self):
        indice_carta = randint(0, len(self.baraja) - 1)
        return self.baraja.pop(indice_carta)




