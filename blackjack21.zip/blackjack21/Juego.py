from Mazo import Mazo
from Crupier import Crupier
from Jugador import Jugador
from Pantalla import Pantalla
from Utils import Utils

class Juego():
    def __init__(self):
        self.baraja = Mazo()
        self.crupier = Crupier()
        self.jugador = Jugador()
        self.juego_finalizado = False

    def verificar_ganadores(self, crupier, jugador):
        pass

    def iniciar_juego(self):
        Pantalla.mensaje_bienvenida()
        input()

        while not self.juego_finalizado:
            #establece las dos cartas el crupier
            self.crupier.agarrar_carta_mazo(self.baraja)
            self.crupier.agarrar_carta_mazo(self.baraja)

            #establece las dos cartas el jugador
            self.jugador.agarrar_carta_mazo(self.baraja)
            self.jugador.agarrar_carta_mazo(self.baraja)

            Pantalla.imprimir_pantalla_estado_jugadores(self.crupier, self.jugador)
            self.jugador.establecer_opcion_jugada(self.baraja, self.crupier)
            Pantalla.limpiar_pantalla()

            self.crupier.establecer_jugada(self.baraja)
            Pantalla.imprimir_pantalla_estado_jugadores(self.crupier, self.jugador)

            Utils.verificar_ganador(self.jugador, self.crupier)



juego = Juego()
juego.iniciar_juego()

Utils.obtener_puntaje_mano(juego.jugador.cartas_jugador)

