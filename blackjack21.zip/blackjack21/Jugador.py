from Utils import *
from Pantalla import Pantalla

class Jugador():

    def __init__(self, monto_jugador = 100):
        self.cartas_jugador = []
        self.monto_jugador = monto_jugador
        self.dinero_por_apostar = 0
        self.terminar_jugada = False

    def mostrar_cartas_jugador(self):
        cadena = ""
        for carta in self.cartas_jugador:
            cadena += "[{}] ".format(carta)

        return cadena

    def agarrar_carta_mazo(self, mazo):
        carta_obtenida = mazo.agarrar_carta()
        carta_obtenida.establecer_carta_arriba()
        self.cartas_jugador.append(carta_obtenida)

    def reclamar_dinero_apostado(self):
        self.monto_jugador += self.dinero_por_apostar
        self.dinero_por_apostar = 0

    def reducir_monto_jugador(self, monto):
        self.monto_jugador -= monto

    def aumentar_monto_crupier(self, monto):
        self.monto_jugador += monto

    def establecer_puntaje_total_cartas(self):
        for carta in self.cartas_jugador:
            self.suma_total_cartas += Utils.obtener_valor_numerico_carta(carta)

    def obtener_puntaje_total_cartas(self):
        return self.suma_total_cartas

    def establecer_opcion_jugada(self, mazo, crupier):
        while True:
            opcion_ingresada = ""

            # verifica que la mano de ambos jugadores no supere el limite de 21 o sea igual a 21 con el fin de definir
            # un jugador ganador y perdedor
            if Utils.obtener_puntaje_mano(self.cartas_jugador) >= 21:
                break
            else:
                Pantalla.limpiar_pantalla()
                Pantalla.imprimir_pantalla_estado_jugadores(crupier, self)
                Pantalla.imprimir_opciones_jugador()
                opcion_ingresada = input()
                Pantalla.limpiar_pantalla()

            if not Utils.es_un_numero(opcion_ingresada):
                print('Ingresa un numero valido')
                continue

            opcion_ingresada = int(opcion_ingresada)

            if opcion_ingresada > 2 or opcion_ingresada < 1:
                print('Favor de ingresar 1 o 2 como opcion')
                continue

            if opcion_ingresada == 1:
                self.agarrar_carta_mazo(mazo)
                continue
            else:
                self.terminar_jugada = True
                break









