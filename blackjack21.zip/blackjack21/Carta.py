class Carta:

    def __init__(self, valor_carta, simbolo_carta, boca_arriba=False):
        self.valor_carta = valor_carta
        self.simbolo_carta = simbolo_carta
        self.boca_arriba = boca_arriba

    def __str__(self):
        return "{} de {}".format(self.valor_carta, self.simbolo_carta)

    def __repr__(self):
        return self.__str__()

    def establecer_carta_arriba(self, boca_arriba=False):
        self.boca_arriba = boca_arriba



